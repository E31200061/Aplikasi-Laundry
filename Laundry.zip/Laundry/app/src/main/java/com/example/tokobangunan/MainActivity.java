package com.example.tokobangunan;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    //Deklarasi Tombol
    Button btn_Databarang,btnUser,btn_Boxin,btnBarangKeluar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get ID tombol & Event Tombol
        btn_Databarang= (Button) findViewById(R.id.btn_Databarang);
        btn_Databarang.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Grafik", Toast.LENGTH_SHORT).show();

            } });

        btnUser= (Button) findViewById(R.id.btnUser);
        btnUser.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Lokasi", Toast.LENGTH_SHORT).show();

            } });

        btn_Boxin= (Button) findViewById(R.id.btn_Boxin);
        btn_Boxin.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Pesan", Toast.LENGTH_SHORT).show();

            } });

        btnBarangKeluar= (Button) findViewById(R.id.btnBarangKeluar);
        btnBarangKeluar.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol View", Toast.LENGTH_SHORT).show();

            } });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}